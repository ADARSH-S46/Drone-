package com.drone.telemetry

import com.drone.telemetry.domain.model.*
import com.drone.telemetry.domain.usecase.DroneRepository
import com.drone.telemetry.presentation.viewmodel.DroneViewModel
import io.mockk.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.*
import org.junit.*

@OptIn(ExperimentalCoroutinesApi::class)
class DroneViewModelTest {

    private val testDispatcher = UnconfinedTestDispatcher()
    private lateinit var repository: DroneRepository
    private lateinit var viewModel: DroneViewModel

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        repository = mockk(relaxed = true)
        every { repository.connectionState } returns MutableStateFlow(ConnectionState.Disconnected)
        every { repository.telemetryData } returns flowOf(TelemetryData())
        viewModel = DroneViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `connect with blank host shows error`() {
        viewModel.onHostChanged("")
        viewModel.onPortChanged("14550")
        viewModel.connect()
        Assert.assertNotNull(viewModel.connectionForm.value.hostError)
    }

    @Test
    fun `connect with invalid port shows error`() {
        viewModel.onHostChanged("192.168.1.1")
        viewModel.onPortChanged("99999")
        viewModel.connect()
        Assert.assertNotNull(viewModel.connectionForm.value.portError)
    }

    @Test
    fun `connect with valid inputs calls repository`() = runTest {
        viewModel.onHostChanged("192.168.1.1")
        viewModel.onPortChanged("14550")
        viewModel.connect()
        coVerify { repository.connect(any()) }
    }

    @Test
    fun `sendCommand arm calls repository`() = runTest {
        coEvery { repository.sendCommand(DroneCommand.Arm) } returns CommandResult.Success
        // Simulate connected state
        every { repository.connectionState } returns MutableStateFlow(ConnectionState.Connected)
        viewModel = DroneViewModel(repository)

        viewModel.sendCommand(DroneCommand.Arm)
        coVerify { repository.sendCommand(DroneCommand.Arm) }
    }

    @Test
    fun `disconnect calls repository disconnect`() = runTest {
        viewModel.disconnect()
        coVerify { repository.disconnect() }
    }
}
