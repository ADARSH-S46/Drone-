package com.drone.telemetry.presentation.dashboard

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.drone.telemetry.domain.model.ConnectionState
import com.drone.telemetry.domain.model.DroneCommand
import com.drone.telemetry.domain.model.TelemetryData
import com.drone.telemetry.presentation.connection.ConnectionStatusBadge
import com.drone.telemetry.presentation.viewmodel.DroneViewModel
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DroneViewModel,
    onDisconnect: () -> Unit
) {
    val state by viewModel.dashboardState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackbar.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Auto-navigate back if disconnected by the system
    LaunchedEffect(state.connectionState) {
        if (state.connectionState is ConnectionState.Disconnected) onDisconnect()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Live Telemetry") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                actions = {
                    TextButton(onClick = {
                        viewModel.disconnect()
                        onDisconnect()
                    }) {
                        Text("Disconnect", color = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Connection status bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ConnectionStatusBadge(state.connectionState)
                ArmStatusBadge(isArmed = state.telemetry.isArmed)
            }

            // Telemetry grid
            TelemetryGrid(telemetry = state.telemetry)

            // Action buttons
            DroneActionButtons(
                onCommand = viewModel::sendCommand,
                enabled = state.connectionState is ConnectionState.Connected
            )

            // Map placeholder (replace with actual Google Maps composable)
            MapSection(
                lat = state.telemetry.latitude,
                lon = state.telemetry.longitude
            )
        }
    }
}

@Composable
fun TelemetryGrid(telemetry: TelemetryData) {
    val batteryColor = when {
        telemetry.batteryPercent < 20 -> Color(0xFFFF5722)  // red
        telemetry.batteryPercent < 40 -> Color(0xFFFF9800)  // orange
        else -> Color(0xFF4CAF50)                            // green
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Telemetry", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TelemetryCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.LocationOn,
                label = "Latitude",
                value = "%.6f°".format(telemetry.latitude)
            )
            TelemetryCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.LocationOn,
                label = "Longitude",
                value = "%.6f°".format(telemetry.longitude)
            )
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TelemetryCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Height,
                label = "Altitude",
                value = "%.1f m".format(telemetry.altitudeMeters)
            )
            TelemetryCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.BatteryFull,
                label = "Battery",
                value = "${telemetry.batteryPercent}%",
                valueColor = batteryColor
            )
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TelemetryCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.FlightTakeoff,
                label = "Flight Mode",
                value = telemetry.flightMode
            )
            TelemetryCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Shield,
                label = "Armed",
                value = if (telemetry.isArmed) "ARMED" else "DISARMED",
                valueColor = if (telemetry.isArmed) Color(0xFFFF5722) else Color(0xFF4CAF50)
            )
        }
    }
}

@Composable
fun TelemetryCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    value: String,
    valueColor: Color? = null
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    icon, contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                value,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = valueColor ?: MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun ArmStatusBadge(isArmed: Boolean) {
    val color by animateColorAsState(
        targetValue = if (isArmed) Color(0xFFFF5722) else Color(0xFF4CAF50),
        animationSpec = tween(300),
        label = "arm_color"
    )
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            if (isArmed) "⚠️ ARMED" else "✅ SAFE",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DroneActionButtons(
    onCommand: (DroneCommand) -> Unit,
    enabled: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onCommand(DroneCommand.Arm) },
                modifier = Modifier.weight(1f),
                enabled = enabled,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
            ) { Text("ARM") }

            Button(
                onClick = { onCommand(DroneCommand.Disarm) },
                modifier = Modifier.weight(1f),
                enabled = enabled,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5722))
            ) { Text("DISARM") }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { onCommand(DroneCommand.Takeoff) },
                modifier = Modifier.weight(1f),
                enabled = enabled
            ) {
                Icon(Icons.Default.FlightTakeoff, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("TAKEOFF")
            }

            OutlinedButton(
                onClick = { onCommand(DroneCommand.ReturnToLaunch) },
                modifier = Modifier.weight(1f),
                enabled = enabled
            ) {
                Icon(Icons.Default.Home, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("RTL")
            }
        }
    }
}

@Composable
fun MapSection(lat: Double, lon: Double) {
    // Placeholder — replace with actual Google Maps Compose integration
    // val cameraState = rememberCameraPositionState {
    //     position = CameraPosition.fromLatLngZoom(LatLng(lat, lon), 16f)
    // }
    // GoogleMap(modifier = Modifier.fillMaxWidth().height(240.dp), cameraPositionState = cameraState) {
    //     if (lat != 0.0 || lon != 0.0) {
    //         Marker(state = MarkerState(position = LatLng(lat, lon)), title = "Drone")
    //     }
    // }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().height(180.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Map, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text("Map: %.5f, %.5f".format(lat, lon), style = MaterialTheme.typography.bodySmall)
            Text(
                "Add MAPS_API_KEY to enable live map",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
