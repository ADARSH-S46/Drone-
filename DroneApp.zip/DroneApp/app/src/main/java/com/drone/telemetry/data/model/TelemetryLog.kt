package com.drone.telemetry.data.model

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "telemetry_log")
data class TelemetryLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Float,
    val batteryPercent: Int,
    val flightMode: String,
    val isArmed: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface TelemetryDao {
    @Insert
    suspend fun insert(entry: TelemetryLogEntity)

    @Query("SELECT * FROM telemetry_log ORDER BY timestamp DESC LIMIT 500")
    fun getRecent(): Flow<List<TelemetryLogEntity>>

    @Query("DELETE FROM telemetry_log WHERE timestamp < :olderThan")
    suspend fun deleteOlderThan(olderThan: Long)
}

@Database(entities = [TelemetryLogEntity::class], version = 1, exportSchema = false)
abstract class DroneDatabase : RoomDatabase() {
    abstract fun telemetryDao(): TelemetryDao
}
