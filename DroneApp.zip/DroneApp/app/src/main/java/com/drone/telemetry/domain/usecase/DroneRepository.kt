package com.drone.telemetry.domain.usecase

import com.drone.telemetry.domain.model.*
import kotlinx.coroutines.flow.Flow

interface DroneRepository {
    val connectionState: Flow<ConnectionState>
    val telemetryData: Flow<TelemetryData>

    suspend fun connect(config: ConnectionConfig)
    suspend fun disconnect()
    suspend fun sendCommand(command: DroneCommand): CommandResult
}
