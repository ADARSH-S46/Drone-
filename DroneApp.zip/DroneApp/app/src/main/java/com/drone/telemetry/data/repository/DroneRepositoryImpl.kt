package com.drone.telemetry.data.repository

import com.drone.telemetry.data.model.TelemetryDao
import com.drone.telemetry.data.model.TelemetryLogEntity
import com.drone.telemetry.data.source.MavlinkDataSource
import com.drone.telemetry.domain.model.*
import com.drone.telemetry.domain.usecase.DroneRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

private const val MAX_RETRY_ATTEMPTS = 5
private const val RETRY_DELAY_MS = 3000L
private const val LOG_INTERVAL_MS = 1000L

@Singleton
class DroneRepositoryImpl @Inject constructor(
    private val mavlink: MavlinkDataSource,
    private val telemetryDao: TelemetryDao
) : DroneRepository {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: Flow<ConnectionState> = _connectionState.asStateFlow()

    override val telemetryData: Flow<TelemetryData> = mavlink.telemetryFlow

    // Simulate local drone state for commands
    private var simulatedArmed = false
    private var simulatedFlying = false

    private var currentConfig: ConnectionConfig? = null
    private var connectJob: Job? = null

    override suspend fun connect(config: ConnectionConfig) {
        currentConfig = config
        connectWithRetry(config)
    }

    private fun connectWithRetry(config: ConnectionConfig) {
        connectJob?.cancel()
        connectJob = scope.launch {
            var attempt = 0
            while (isActive) {
                try {
                    _connectionState.value = if (attempt == 0)
                        ConnectionState.Connecting
                    else
                        ConnectionState.Reconnecting(attempt)

                    Timber.d("Connecting to ${config.toEndpoint()} (attempt ${attempt + 1})")
                    mavlink.connect(config)
                    _connectionState.value = ConnectionState.Connected

                    // Watch for disconnection by monitoring telemetry timeout
                    watchForDisconnect()
                    attempt = 0 // reset on success

                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Timber.e(e, "Connection failed attempt $attempt")
                    attempt++
                    if (attempt >= MAX_RETRY_ATTEMPTS) {
                        _connectionState.value = ConnectionState.Error(
                            "Failed after $MAX_RETRY_ATTEMPTS attempts: ${e.message}"
                        )
                        break
                    }
                    delay(RETRY_DELAY_MS)
                }
            }
        }

        // Start telemetry logging in parallel
        scope.launch { startLogging() }
    }

    private suspend fun watchForDisconnect() = coroutineScope {
        // If no telemetry arrives for 5 seconds, treat as disconnected
        var lastReceived = System.currentTimeMillis()
        val monitorJob = launch {
            telemetryData.collect { lastReceived = System.currentTimeMillis() }
        }
        while (isActive) {
            delay(2000)
            if (System.currentTimeMillis() - lastReceived > 5000 && !mavlink.isConnected()) {
                monitorJob.cancel()
                throw Exception("Telemetry stream timed out")
            }
        }
        monitorJob.cancel()
    }

    private suspend fun startLogging() {
        var lastLog = 0L
        telemetryData.collect { data ->
            val now = System.currentTimeMillis()
            if (now - lastLog >= LOG_INTERVAL_MS) {
                lastLog = now
                telemetryDao.insert(
                    TelemetryLogEntity(
                        latitude = data.latitude,
                        longitude = data.longitude,
                        altitudeMeters = data.altitudeMeters,
                        batteryPercent = data.batteryPercent,
                        flightMode = data.flightMode,
                        isArmed = data.isArmed
                    )
                )
            }
        }
    }

    override suspend fun disconnect() {
        connectJob?.cancel()
        mavlink.disconnect()
        _connectionState.value = ConnectionState.Disconnected
        currentConfig = null
    }

    override suspend fun sendCommand(command: DroneCommand): CommandResult {
        if (_connectionState.value !is ConnectionState.Connected) {
            return CommandResult.Failure("Not connected to drone")
        }
        // Simulate state changes locally (real MAVLink command sending would use mavlink.sendCommand)
        return when (command) {
            DroneCommand.Arm -> {
                simulatedArmed = true
                Timber.d("Command: ARM sent")
                CommandResult.Success
            }
            DroneCommand.Disarm -> {
                simulatedArmed = false
                simulatedFlying = false
                Timber.d("Command: DISARM sent")
                CommandResult.Success
            }
            DroneCommand.Takeoff -> {
                if (!simulatedArmed) return CommandResult.Failure("Arm the drone first")
                simulatedFlying = true
                Timber.d("Command: TAKEOFF sent")
                CommandResult.Success
            }
            DroneCommand.ReturnToLaunch -> {
                Timber.d("Command: RTL sent")
                CommandResult.Success
            }
        }
    }
}
