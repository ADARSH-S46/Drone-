package com.drone.telemetry.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.drone.telemetry.presentation.connection.ConnectionScreen
import com.drone.telemetry.presentation.dashboard.DashboardScreen
import com.drone.telemetry.presentation.theme.DroneTelemetryTheme
import com.drone.telemetry.presentation.viewmodel.DroneViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: DroneViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DroneTelemetryTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DroneNavGraph(viewModel)
                }
            }
        }
    }
}

@Composable
fun DroneNavGraph(viewModel: DroneViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "connection") {
        composable("connection") {
            ConnectionScreen(
                viewModel = viewModel,
                onConnected = {
                    navController.navigate("dashboard") {
                        popUpTo("connection") { inclusive = true }
                    }
                }
            )
        }
        composable("dashboard") {
            DashboardScreen(
                viewModel = viewModel,
                onDisconnect = {
                    navController.navigate("connection") {
                        popUpTo("dashboard") { inclusive = true }
                    }
                }
            )
        }
    }
}
