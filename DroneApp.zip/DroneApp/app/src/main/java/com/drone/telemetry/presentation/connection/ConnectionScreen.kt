package com.drone.telemetry.presentation.connection

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.drone.telemetry.domain.model.ConnectionConfig
import com.drone.telemetry.domain.model.ConnectionState
import com.drone.telemetry.presentation.viewmodel.ConnectionUiState
import com.drone.telemetry.presentation.viewmodel.DroneViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectionScreen(
    viewModel: DroneViewModel,
    onConnected: () -> Unit
) {
    val form by viewModel.connectionForm.collectAsState()
    val dashboard by viewModel.dashboardState.collectAsState()

    // Navigate away when connected
    LaunchedEffect(dashboard.connectionState) {
        if (dashboard.connectionState is ConnectionState.Connected) onConnected()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Drone Telemetry") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.FlightTakeoff,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Text(
                "Connect to MAVLink Stream",
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(Modifier.height(8.dp))

            // Protocol selector
            ProtocolSelector(
                selected = form.protocol,
                onSelect = viewModel::onProtocolChanged
            )

            // Host field
            OutlinedTextField(
                value = form.host,
                onValueChange = viewModel::onHostChanged,
                label = { Text("IP Address") },
                placeholder = { Text("192.168.1.12") },
                isError = form.hostError != null,
                supportingText = form.hostError?.let { { Text(it) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Port field
            OutlinedTextField(
                value = form.port,
                onValueChange = viewModel::onPortChanged,
                label = { Text("Port") },
                placeholder = { Text("14550") },
                isError = form.portError != null,
                supportingText = form.portError?.let { { Text(it) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(Modifier.height(8.dp))

            // Status indicator
            ConnectionStatusBadge(state = dashboard.connectionState)

            Spacer(Modifier.height(8.dp))

            // Connect button
            Button(
                onClick = viewModel::connect,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled = dashboard.connectionState !is ConnectionState.Connecting
                        && dashboard.connectionState !is ConnectionState.Reconnecting
            ) {
                if (dashboard.connectionState is ConnectionState.Connecting ||
                    dashboard.connectionState is ConnectionState.Reconnecting
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(8.dp))
                    val attempt = (dashboard.connectionState as? ConnectionState.Reconnecting)?.attempt
                    Text(if (attempt != null) "Reconnecting ($attempt)..." else "Connecting...")
                } else {
                    Text("Connect")
                }
            }

            // Error message
            AnimatedVisibility(dashboard.connectionState is ConnectionState.Error) {
                val msg = (dashboard.connectionState as? ConnectionState.Error)?.message ?: ""
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "⚠️ $msg",
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun ProtocolSelector(
    selected: ConnectionConfig.Protocol,
    onSelect: (ConnectionConfig.Protocol) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ConnectionConfig.Protocol.entries.forEach { protocol ->
            FilterChip(
                selected = selected == protocol,
                onClick = { onSelect(protocol) },
                label = { Text(protocol.name) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun ConnectionStatusBadge(state: ConnectionState) {
    val (label, color) = when (state) {
        ConnectionState.Disconnected -> "Disconnected" to MaterialTheme.colorScheme.error
        ConnectionState.Connecting -> "Connecting..." to MaterialTheme.colorScheme.tertiary
        ConnectionState.Connected -> "Connected" to MaterialTheme.colorScheme.primary
        is ConnectionState.Reconnecting -> "Reconnecting (${state.attempt})..." to MaterialTheme.colorScheme.tertiary
        is ConnectionState.Error -> "Error" to MaterialTheme.colorScheme.error
    }
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = MaterialTheme.shapes.small
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                modifier = Modifier.size(8.dp),
                shape = MaterialTheme.shapes.extraSmall,
                color = color
            ) {}
            Text(label, style = MaterialTheme.typography.labelMedium, color = color)
        }
    }
}
