package com.drone.telemetry.domain.model

data class TelemetryData(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val altitudeMeters: Float = 0f,
    val batteryPercent: Int = 0,
    val flightMode: String = "UNKNOWN",
    val isArmed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class ConnectionConfig(
    val host: String,
    val port: Int,
    val protocol: Protocol
) {
    enum class Protocol { UDP, TCP }

    fun toEndpoint(): String = "${protocol.name.lowercase()}://$host:$port"
}

sealed class ConnectionState {
    object Disconnected : ConnectionState()
    object Connecting : ConnectionState()
    object Connected : ConnectionState()
    data class Reconnecting(val attempt: Int) : ConnectionState()
    data class Error(val message: String) : ConnectionState()
}

sealed class DroneCommand {
    object Arm : DroneCommand()
    object Disarm : DroneCommand()
    object Takeoff : DroneCommand()
    object ReturnToLaunch : DroneCommand()
}

sealed class CommandResult {
    object Success : CommandResult()
    data class Failure(val reason: String) : CommandResult()
}
