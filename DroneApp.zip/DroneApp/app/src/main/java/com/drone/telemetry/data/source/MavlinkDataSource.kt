package com.drone.telemetry.data.source

import com.drone.telemetry.domain.model.ConnectionConfig
import com.drone.telemetry.domain.model.TelemetryData
import io.dronefleet.mavlink.MavlinkConnection
import io.dronefleet.mavlink.common.GlobalPositionInt
import io.dronefleet.mavlink.common.Heartbeat
import io.dronefleet.mavlink.common.SysStatus
import io.dronefleet.mavlink.minimal.MavMode
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import timber.log.Timber
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.Socket
import java.net.SocketTimeoutException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MavlinkDataSource @Inject constructor() {

    private val _telemetryFlow = MutableSharedFlow<TelemetryData>(replay = 1)
    val telemetryFlow: SharedFlow<TelemetryData> = _telemetryFlow

    private var readJob: Job? = null
    private var udpSocket: DatagramSocket? = null
    private var tcpSocket: Socket? = null
    private var mavlinkConnection: MavlinkConnection? = null

    // Mutable state we aggregate across messages
    private var lat = 0.0
    private var lon = 0.0
    private var alt = 0f
    private var battery = 0
    private var flightMode = "UNKNOWN"
    private var isArmed = false

    suspend fun connect(config: ConnectionConfig) = withContext(Dispatchers.IO) {
        disconnect()
        when (config.protocol) {
            ConnectionConfig.Protocol.UDP -> connectUdp(config)
            ConnectionConfig.Protocol.TCP -> connectTcp(config)
        }
    }

    private fun connectUdp(config: ConnectionConfig) {
        udpSocket = DatagramSocket(config.port).apply {
            soTimeout = 5000
            reuseAddress = true
        }
        val inputStream = UdpInputStream(udpSocket!!, config.host, config.port)
        mavlinkConnection = MavlinkConnection.create(inputStream, inputStream.outputStream)
        startReading()
    }

    private fun connectTcp(config: ConnectionConfig) {
        tcpSocket = Socket(config.host, config.port).apply {
            soTimeout = 5000
        }
        mavlinkConnection = MavlinkConnection.create(
            tcpSocket!!.getInputStream(),
            tcpSocket!!.getOutputStream()
        )
        startReading()
    }

    private fun startReading() {
        readJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                while (isActive) {
                    val message = mavlinkConnection?.next() ?: break
                    when (val payload = message.payload) {
                        is GlobalPositionInt -> {
                            lat = payload.lat() / 1e7
                            lon = payload.lon() / 1e7
                            alt = payload.relativeAlt() / 1000f
                            emitTelemetry()
                        }
                        is SysStatus -> {
                            battery = payload.batteryRemaining().toInt()
                            emitTelemetry()
                        }
                        is Heartbeat -> {
                            val baseMode = payload.baseMode().value()
                            isArmed = (baseMode and MavMode.MAV_MODE_FLAG_SAFETY_ARMED.value()) != 0
                            flightMode = resolveFlightMode(payload.customMode())
                            emitTelemetry()
                        }
                    }
                }
            } catch (e: SocketTimeoutException) {
                Timber.w("MAVLink read timeout")
                throw e
            } catch (e: IOException) {
                Timber.e(e, "MAVLink read error")
                throw e
            }
        }
    }

    private suspend fun emitTelemetry() {
        _telemetryFlow.emit(
            TelemetryData(
                latitude = lat,
                longitude = lon,
                altitudeMeters = alt,
                batteryPercent = battery.coerceIn(0, 100),
                flightMode = flightMode,
                isArmed = isArmed
            )
        )
    }

    private fun resolveFlightMode(customMode: Long): String = when (customMode.toInt()) {
        0 -> "STABILIZE"
        1 -> "ACRO"
        2 -> "ALT_HOLD"
        3 -> "AUTO"
        4 -> "GUIDED"
        5 -> "LOITER"
        6 -> "RTL"
        7 -> "CIRCLE"
        9 -> "LAND"
        else -> "MODE_$customMode"
    }

    fun disconnect() {
        readJob?.cancel()
        readJob = null
        try {
            mavlinkConnection?.close()
            udpSocket?.close()
            tcpSocket?.close()
        } catch (e: Exception) {
            Timber.e(e, "Error during disconnect")
        }
        mavlinkConnection = null
        udpSocket = null
        tcpSocket = null
    }

    fun isConnected(): Boolean = readJob?.isActive == true
}

/**
 * Adapter that wraps a DatagramSocket into an InputStream so MavlinkConnection can use it.
 */
class UdpInputStream(
    private val socket: DatagramSocket,
    host: String,
    port: Int
) : java.io.InputStream() {

    private val buffer = ByteArray(1024)
    private val packet = DatagramPacket(buffer, buffer.size)
    private var pos = 0
    private var len = 0
    private val remoteAddress = InetAddress.getByName(host)
    private val remotePort = port

    val outputStream = object : java.io.OutputStream() {
        override fun write(b: ByteArray, off: Int, len: Int) {
            val sendPacket = DatagramPacket(b, off, len, remoteAddress, remotePort)
            socket.send(sendPacket)
        }
        override fun write(b: Int) = write(byteArrayOf(b.toByte()))
    }

    override fun read(): Int {
        if (pos >= len) {
            socket.receive(packet)
            len = packet.length
            pos = 0
        }
        return buffer[pos++].toInt() and 0xFF
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (pos >= this.len) {
            socket.receive(packet)
            this.len = packet.length
            pos = 0
        }
        val available = this.len - pos
        val toRead = minOf(len, available)
        System.arraycopy(buffer, pos, b, off, toRead)
        pos += toRead
        return toRead
    }
}
