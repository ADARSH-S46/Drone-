package com.drone.telemetry.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.drone.telemetry.domain.model.*
import com.drone.telemetry.domain.usecase.DroneRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ConnectionUiState(
    val host: String = "192.168.1.12",
    val port: String = "14550",
    val protocol: ConnectionConfig.Protocol = ConnectionConfig.Protocol.UDP,
    val hostError: String? = null,
    val portError: String? = null
)

data class DashboardUiState(
    val telemetry: TelemetryData = TelemetryData(),
    val connectionState: ConnectionState = ConnectionState.Disconnected,
    val lastCommandResult: String? = null
)

@HiltViewModel
class DroneViewModel @Inject constructor(
    private val repository: DroneRepository
) : ViewModel() {

    private val _connectionForm = MutableStateFlow(ConnectionUiState())
    val connectionForm: StateFlow<ConnectionUiState> = _connectionForm.asStateFlow()

    val dashboardState: StateFlow<DashboardUiState> = combine(
        repository.telemetryData.onStart { emit(TelemetryData()) },
        repository.connectionState
    ) { telemetry, connection ->
        DashboardUiState(telemetry = telemetry, connectionState = connection)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    private val _snackbar = MutableSharedFlow<String>()
    val snackbar: SharedFlow<String> = _snackbar.asSharedFlow()

    fun onHostChanged(value: String) {
        _connectionForm.update { it.copy(host = value, hostError = null) }
    }

    fun onPortChanged(value: String) {
        _connectionForm.update { it.copy(port = value, portError = null) }
    }

    fun onProtocolChanged(protocol: ConnectionConfig.Protocol) {
        _connectionForm.update { it.copy(protocol = protocol) }
    }

    fun connect() {
        val form = _connectionForm.value
        val port = form.port.toIntOrNull()

        var hasError = false
        if (form.host.isBlank() || !isValidIp(form.host)) {
            _connectionForm.update { it.copy(hostError = "Enter a valid IP address") }
            hasError = true
        }
        if (port == null || port !in 1..65535) {
            _connectionForm.update { it.copy(portError = "Enter a valid port (1–65535)") }
            hasError = true
        }
        if (hasError) return

        viewModelScope.launch {
            try {
                repository.connect(ConnectionConfig(form.host, port!!, form.protocol))
            } catch (e: Exception) {
                _snackbar.emit("Connection error: ${e.message}")
            }
        }
    }

    fun disconnect() {
        viewModelScope.launch { repository.disconnect() }
    }

    fun sendCommand(command: DroneCommand) {
        viewModelScope.launch {
            val result = repository.sendCommand(command)
            val msg = when (result) {
                is CommandResult.Success -> "${commandName(command)} sent successfully"
                is CommandResult.Failure -> "Command failed: ${result.reason}"
            }
            _snackbar.emit(msg)
        }
    }

    private fun commandName(cmd: DroneCommand) = when (cmd) {
        DroneCommand.Arm -> "ARM"
        DroneCommand.Disarm -> "DISARM"
        DroneCommand.Takeoff -> "TAKEOFF"
        DroneCommand.ReturnToLaunch -> "RTL"
    }

    private fun isValidIp(ip: String): Boolean {
        val parts = ip.split(".")
        if (parts.size != 4) return false
        return parts.all { part ->
            val n = part.toIntOrNull()
            n != null && n in 0..255
        }
    }
}
