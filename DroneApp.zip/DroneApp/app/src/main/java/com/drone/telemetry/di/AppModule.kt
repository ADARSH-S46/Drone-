package com.drone.telemetry.di

import android.content.Context
import androidx.room.Room
import com.drone.telemetry.data.model.DroneDatabase
import com.drone.telemetry.data.model.TelemetryDao
import com.drone.telemetry.data.repository.DroneRepositoryImpl
import com.drone.telemetry.domain.usecase.DroneRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): DroneDatabase =
        Room.databaseBuilder(ctx, DroneDatabase::class.java, "drone_telemetry.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideTelemetryDao(db: DroneDatabase): TelemetryDao = db.telemetryDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindDroneRepository(impl: DroneRepositoryImpl): DroneRepository
}
