# Drone Telemetry Viewer

An Android application that connects to a MAVLink telemetry stream and displays live drone telemetry data in real-time.

---

## Setup

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or later
- JDK 17
- Android SDK 34

### Steps
1. Clone the repository
2. Open in Android Studio
3. Add your Google Maps API key in `local.properties`:
   ```
   MAPS_API_KEY=your_key_here
   ```
4. Sync Gradle and run on a device/emulator (API 26+)

### Testing with a Simulated Drone
Use Mission Planner or ArduPilot SITL to generate a MAVLink stream:
```bash
# SITL example
sim_vehicle.py -v ArduCopter --out udp:0.0.0.0:14550
```
Then connect the app to your machine's IP on port `14550` via UDP.

---

## Architecture

The app follows **Clean Architecture** with **MVVM** presentation layer:

```
presentation/       ← Compose UI + ViewModels
domain/             ← Models, use-cases, repository interface
data/               ← Repository impl, MAVLink source, Room DB
di/                 ← Hilt modules
```

**Data flow:**
```
MavlinkDataSource (socket)
    → MutableSharedFlow<TelemetryData>
    → DroneRepositoryImpl
    → DroneViewModel (StateFlow)
    → Compose UI (collectAsState)
```

---

## Libraries

| Library | Purpose |
|---|---|
| Jetpack Compose | UI |
| Hilt | Dependency Injection |
| Coroutines / Flow | Async + reactive streams |
| io.dronefleet:mavlink | MAVLink protocol parsing |
| Room | Local telemetry logging |
| Maps Compose | Live map view |
| Timber | Logging |
| MockK | Unit testing |

---

## Features

- ✅ UDP + TCP MAVLink connection
- ✅ Live telemetry: GPS, altitude, battery, flight mode, arm status
- ✅ Auto-reconnect with retry (up to 5 attempts)
- ✅ Drone action buttons: Arm, Disarm, Takeoff, RTL
- ✅ Color-coded status indicators (green/red/orange)
- ✅ Local telemetry logging (Room DB)
- ✅ Dark mode support
- ✅ Input validation with clear error messages
- ✅ Unit tests for ViewModel

---

## Assumptions & Limitations

- **Command execution is simulated** — actual MAVLink command packets (e.g. `COMMAND_LONG`) are not sent; state changes are local only. Implementing real command sending requires matching the system/component ID of the connected GCS.
- **MAVLink v1 and v2** are both supported via the dronefleet library.
- The **Maps API key** must be supplied separately; the map card shows coordinates as text without it.
- **Battery percentage** comes from `SYS_STATUS`; if the drone doesn't send this message, it defaults to 0.
- Flight mode labels are mapped for **ArduCopter** custom modes; other firmwares may show `MODE_N`.
