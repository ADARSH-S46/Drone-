package com.example.dronefleet.repository;

import com.example.dronefleet.model.Drone;

import java.util.ArrayList;
import java.util.List;

public class DroneRepository {

    // Singleton
    private static DroneRepository instance;

    private DroneRepository() {}

    public static DroneRepository getInstance() {
        if (instance == null) {
            instance = new DroneRepository();
        }
        return instance;
    }

    public List<Drone> getAllDrones() {
        List<Drone> droneList = new ArrayList<>();

        droneList.add(new Drone("GA-001", "Survey Drone", 85, "Flying", "Mysore",
                120.5, 45.2, "2025-06-20 10:30 AM"));

        droneList.add(new Drone("GA-002", "Spray Drone", 42, "Idle", "Mandya",
                0.0, 0.0, "2025-06-20 09:15 AM"));

        droneList.add(new Drone("GA-003", "Mapping Drone", 18, "Charging", "Bangalore",
                0.0, 0.0, "2025-06-20 08:45 AM"));

        droneList.add(new Drone("GA-004", "Inspection Drone", 67, "Flying", "Tumkur",
                95.0, 38.7, "2025-06-20 11:00 AM"));

        droneList.add(new Drone("GA-005", "Agriculture Drone", 95, "Idle", "Hassan",
                0.0, 0.0, "2025-06-20 07:30 AM"));

        return droneList;
    }
}
