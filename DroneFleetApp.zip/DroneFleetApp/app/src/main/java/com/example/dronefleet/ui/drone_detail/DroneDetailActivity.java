package com.example.dronefleet.ui.drone_detail;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.dronefleet.R;
import com.example.dronefleet.model.Drone;
import com.example.dronefleet.utils.BatteryUtils;

public class DroneDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drone_detail);

        Drone drone = (Drone) getIntent().getSerializableExtra("drone");

        if (drone == null) {
            finish();
            return;
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(drone.getDroneName());
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        bindData(drone);
    }

    private void bindData(Drone drone) {
        TextView tvDroneId = findViewById(R.id.tvDroneId);
        TextView tvDroneName = findViewById(R.id.tvDroneName);
        TextView tvBattery = findViewById(R.id.tvBattery);
        TextView tvBatteryStatus = findViewById(R.id.tvBatteryStatus);
        TextView tvStatus = findViewById(R.id.tvStatus);
        TextView tvLocation = findViewById(R.id.tvLocation);
        TextView tvAltitude = findViewById(R.id.tvAltitude);
        TextView tvSpeed = findViewById(R.id.tvSpeed);
        TextView tvLastUpdated = findViewById(R.id.tvLastUpdated);
        ProgressBar progressBattery = findViewById(R.id.progressBattery);

        tvDroneId.setText(drone.getDroneId());
        tvDroneName.setText(drone.getDroneName());
        tvBattery.setText(drone.getBattery() + "%");
        tvBatteryStatus.setText(BatteryUtils.getBatteryStatus(drone.getBattery()));
        tvStatus.setText(drone.getStatus());
        tvLocation.setText(drone.getLocation());
        tvAltitude.setText(drone.getAltitude() + " m");
        tvSpeed.setText(drone.getSpeed() + " km/h");
        tvLastUpdated.setText(drone.getLastUpdated());

        progressBattery.setProgress(drone.getBattery());
        progressBattery.getProgressDrawable()
                .setColorFilter(BatteryUtils.getBatteryColor(drone.getBattery()),
                        android.graphics.PorterDuff.Mode.SRC_IN);

        tvBatteryStatus.setTextColor(BatteryUtils.getBatteryColor(drone.getBattery()));
        tvStatus.setTextColor(BatteryUtils.getStatusColor(drone.getStatus()));
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
