package com.example.dronefleet.ui.drone_list;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.dronefleet.R;
import com.example.dronefleet.model.Drone;
import com.example.dronefleet.ui.adapter.DroneAdapter;
import com.example.dronefleet.ui.drone_detail.DroneDetailActivity;
import com.example.dronefleet.viewmodel.DroneViewModel;

public class DroneListActivity extends AppCompatActivity implements DroneAdapter.OnDroneClickListener {

    private DroneViewModel viewModel;
    private DroneAdapter adapter;

    private RecyclerView recyclerView;
    private EditText etSearch;
    private Spinner spinnerFilter, spinnerSort;
    private TextView tvEmptyMessage;
    private SwipeRefreshLayout swipeRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drone_list);

        initViews();
        setupRecyclerView();
        setupViewModel();
        setupSearch();
        setupFilter();
        setupSort();
        setupSwipeRefresh();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        etSearch = findViewById(R.id.etSearch);
        spinnerFilter = findViewById(R.id.spinnerFilter);
        spinnerSort = findViewById(R.id.spinnerSort);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);
        swipeRefresh = findViewById(R.id.swipeRefresh);
    }

    private void setupRecyclerView() {
        adapter = new DroneAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(DroneViewModel.class);

        viewModel.getDroneLiveData().observe(this, drones -> {
            adapter.setDroneList(drones);
            swipeRefresh.setRefreshing(false);
        });

        viewModel.getErrorMessage().observe(this, message -> {
            if (message != null) {
                tvEmptyMessage.setVisibility(View.VISIBLE);
                tvEmptyMessage.setText(message);
                recyclerView.setVisibility(View.GONE);
            } else {
                tvEmptyMessage.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                viewModel.search(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void setupFilter() {
        String[] filterOptions = {"All", "Flying", "Idle", "Charging"};
        ArrayAdapter<String> filterAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, filterOptions);
        filterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(filterAdapter);

        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                viewModel.filterByStatus(filterOptions[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupSort() {
        String[] sortOptions = {"None", "High to Low", "Low to High"};
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, sortOptions);
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSort.setAdapter(sortAdapter);

        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                viewModel.sortByBattery(sortOptions[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupSwipeRefresh() {
        swipeRefresh.setOnRefreshListener(() -> {
            viewModel.refresh();
            Toast.makeText(this, "Refreshed", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onDroneClick(Drone drone) {
        Intent intent = new Intent(this, DroneDetailActivity.class);
        intent.putExtra("drone", drone);
        startActivity(intent);
    }
}
