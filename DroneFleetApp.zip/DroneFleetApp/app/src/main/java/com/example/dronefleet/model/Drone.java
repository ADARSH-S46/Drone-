package com.example.dronefleet.model;

import java.io.Serializable;

public class Drone implements Serializable {

    private String droneId;
    private String droneName;
    private int battery;
    private String status;
    private String location;
    private double altitude;
    private double speed;
    private String lastUpdated;

    public Drone(String droneId, String droneName, int battery, String status, String location,
                 double altitude, double speed, String lastUpdated) {
        this.droneId = droneId;
        this.droneName = droneName;
        this.battery = battery;
        this.status = status;
        this.location = location;
        this.altitude = altitude;
        this.speed = speed;
        this.lastUpdated = lastUpdated;
    }

    public String getDroneId() { return droneId; }
    public String getDroneName() { return droneName; }
    public int getBattery() { return battery; }
    public String getStatus() { return status; }
    public String getLocation() { return location; }
    public double getAltitude() { return altitude; }
    public double getSpeed() { return speed; }
    public String getLastUpdated() { return lastUpdated; }
}
