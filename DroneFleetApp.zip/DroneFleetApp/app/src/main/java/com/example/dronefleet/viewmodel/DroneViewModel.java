package com.example.dronefleet.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.dronefleet.model.Drone;
import com.example.dronefleet.repository.DroneRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DroneViewModel extends ViewModel {

    private final DroneRepository repository;

    private final MutableLiveData<List<Drone>> droneLiveData = new MutableLiveData<>();
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>();

    private List<Drone> allDrones = new ArrayList<>();
    private String currentSearch = "";
    private String currentFilter = "All";
    private String currentSort = "None";

    public DroneViewModel() {
        repository = DroneRepository.getInstance();
        loadDrones();
    }

    public LiveData<List<Drone>> getDroneLiveData() {
        return droneLiveData;
    }

    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    private void loadDrones() {
        allDrones = repository.getAllDrones();
        applyFilters();
    }

    public void search(String query) {
        currentSearch = query.trim().toLowerCase();
        applyFilters();
    }

    public void filterByStatus(String status) {
        currentFilter = status;
        applyFilters();
    }

    public void sortByBattery(String order) {
        currentSort = order;
        applyFilters();
    }

    public void refresh() {
        loadDrones();
    }

    private void applyFilters() {
        List<Drone> result = new ArrayList<>();

        for (Drone drone : allDrones) {
            // apply search
            boolean matchesSearch = currentSearch.isEmpty()
                    || drone.getDroneId().toLowerCase().contains(currentSearch)
                    || drone.getDroneName().toLowerCase().contains(currentSearch)
                    || drone.getLocation().toLowerCase().contains(currentSearch);

            // apply filter
            boolean matchesFilter = currentFilter.equals("All")
                    || drone.getStatus().equals(currentFilter);

            if (matchesSearch && matchesFilter) {
                result.add(drone);
            }
        }

        // apply sort
        if (currentSort.equals("High to Low")) {
            Collections.sort(result, (a, b) -> b.getBattery() - a.getBattery());
        } else if (currentSort.equals("Low to High")) {
            Collections.sort(result, (a, b) -> a.getBattery() - b.getBattery());
        }

        if (result.isEmpty()) {
            errorMessage.setValue("No drones found.");
        } else {
            errorMessage.setValue(null);
        }

        droneLiveData.setValue(result);
    }

    public List<Drone> getAllDrones() {
        return allDrones;
    }
}
