package com.example.dronefleet.utils;

import android.graphics.Color;

public class BatteryUtils {

    public static final String STATUS_HEALTHY = "Healthy";
    public static final String STATUS_WARNING = "Warning";
    public static final String STATUS_CRITICAL = "Critical";

    public static String getBatteryStatus(int battery) {
        if (battery > 50) {
            return STATUS_HEALTHY;
        } else if (battery >= 20) {
            return STATUS_WARNING;
        } else {
            return STATUS_CRITICAL;
        }
    }

    public static int getBatteryColor(int battery) {
        if (battery > 50) {
            return Color.parseColor("#4CAF50"); // green
        } else if (battery >= 20) {
            return Color.parseColor("#FF9800"); // orange
        } else {
            return Color.parseColor("#F44336"); // red
        }
    }

    public static int getStatusColor(String status) {
        switch (status) {
            case "Flying":
                return Color.parseColor("#2196F3"); // blue
            case "Idle":
                return Color.parseColor("#9E9E9E"); // grey
            case "Charging":
                return Color.parseColor("#4CAF50"); // green
            default:
                return Color.parseColor("#9E9E9E");
        }
    }
}
