package com.example.dronefleet.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dronefleet.R;
import com.example.dronefleet.model.Drone;
import com.example.dronefleet.utils.BatteryUtils;

import java.util.ArrayList;
import java.util.List;

public class DroneAdapter extends RecyclerView.Adapter<DroneAdapter.DroneViewHolder> {

    private List<Drone> droneList = new ArrayList<>();
    private OnDroneClickListener listener;

    public interface OnDroneClickListener {
        void onDroneClick(Drone drone);
    }

    public DroneAdapter(OnDroneClickListener listener) {
        this.listener = listener;
    }

    public void setDroneList(List<Drone> list) {
        this.droneList = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DroneViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_drone, parent, false);
        return new DroneViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DroneViewHolder holder, int position) {
        Drone drone = droneList.get(position);
        holder.bind(drone, listener);
    }

    @Override
    public int getItemCount() {
        return droneList.size();
    }

    static class DroneViewHolder extends RecyclerView.ViewHolder {

        TextView tvDroneId, tvDroneName, tvStatus, tvLocation, tvBattery, tvBatteryStatus;
        ProgressBar progressBattery;

        public DroneViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDroneId = itemView.findViewById(R.id.tvDroneId);
            tvDroneName = itemView.findViewById(R.id.tvDroneName);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvBattery = itemView.findViewById(R.id.tvBattery);
            tvBatteryStatus = itemView.findViewById(R.id.tvBatteryStatus);
            progressBattery = itemView.findViewById(R.id.progressBattery);
        }

        public void bind(Drone drone, OnDroneClickListener listener) {
            tvDroneId.setText(drone.getDroneId());
            tvDroneName.setText(drone.getDroneName());
            tvStatus.setText(drone.getStatus());
            tvLocation.setText(drone.getLocation());
            tvBattery.setText(drone.getBattery() + "%");
            tvBatteryStatus.setText(BatteryUtils.getBatteryStatus(drone.getBattery()));

            progressBattery.setProgress(drone.getBattery());
            progressBattery.getProgressDrawable()
                    .setColorFilter(BatteryUtils.getBatteryColor(drone.getBattery()),
                            android.graphics.PorterDuff.Mode.SRC_IN);

            tvStatus.setTextColor(BatteryUtils.getStatusColor(drone.getStatus()));
            tvBatteryStatus.setTextColor(BatteryUtils.getBatteryColor(drone.getBattery()));

            itemView.setOnClickListener(v -> listener.onDroneClick(drone));
        }
    }
}
