# Drone Fleet Management App

## Folder Structure
```
app/src/main/java/com/example/dronefleet/
├── model/
│   └── Drone.java                  # Data model class
├── repository/
│   └── DroneRepository.java        # Data source (mock data)
├── viewmodel/
│   └── DroneViewModel.java         # ViewModel for list screen
├── ui/
│   ├── adapter/
│   │   └── DroneAdapter.java       # RecyclerView adapter
│   ├── drone_list/
│   │   └── DroneListActivity.java  # Main list screen
│   └── drone_detail/
│       └── DroneDetailActivity.java # Detail screen
└── utils/
    └── BatteryUtils.java           # Battery helper
```

## Tech Stack
- Java
- MVVM Architecture
- ViewBinding
- RecyclerView
- LiveData
- Navigation via Intents
